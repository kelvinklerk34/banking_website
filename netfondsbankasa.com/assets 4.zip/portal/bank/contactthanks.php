<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<head>
	<title>    SWISS STOCKS CORPORATION</title>
	
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

	<div id="page-wrap">

		<img src=" " alt="" />
		<p><!--<a href="http://css-tricks.com"></a>-->
		    <H3> Congratulations! </h3>
		</p>
			
			
		<br /><br />
		
			
		<h1>Your message has been sent!</h1><br />
		
		<p><a href="changePassword.php">Back to Contact Form</a></p>
	
	</div>
	
	<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
	</script>
	<script type="text/javascript">
	_uacct = "UA-68528-29";
	urchinTracker();
	</script>

</body>

</html>